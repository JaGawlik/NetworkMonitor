﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Json;
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using System.Diagnostics;
using NetworkMonitor.AppConfiguration;
using NetworkMonitor.Model;
using NetworkMonitor.Repository;
using NetworkMonitor.Snort;
using NetworkMonitor.Windows;
using NetworkMonitor.Windows.Views;

namespace NetworkMonitor
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private int _lastMaxId = 0;
        private DispatcherTimer _timer;
        public ICommand UpdateAlertStatusCommand { get; }
        public RelayCommand<object> SearchAlertsByIpCommand { get; }


        private Process _snortProcess;
        private SnortManagerService _snortManagerService;
        private SnortAlertMonitor _snortAlertMonitor;

        private bool _isSnortInitialized = false;

        private User _currentUser;
        public User CurrentUser
        {
            get => _currentUser ??= new User { Role = "User", Username = "Niezalogowany" };
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
            }
        }



        private object _currentView;
        public object CurrentView
        {
            get => _currentView;
            set
            {
                _currentView = value;
                OnPropertyChanged(nameof(CurrentView));
            }
        }

        private int _selectedTabIndex;
        public int SelectedTabIndex
        {
            get => _selectedTabIndex;
            set
            {
                _selectedTabIndex = value;
                OnPropertyChanged(nameof(SelectedTabIndex));
                UpdateCurrentView();
            }
        }

        private bool _isAdminLoggedIn = false;
        public bool IsAdminLoggedIn
        {
            get => _isAdminLoggedIn;
            set
            {
                _isAdminLoggedIn = value;
                OnPropertyChanged(nameof(IsAdminLoggedIn));
            }
        }

        private string _searchSourceIp;
        public string SearchSourceIp
        {
            get => _searchSourceIp;
            set
            {
                if (_searchSourceIp != value)
                {
                    _searchSourceIp = value;
                    OnPropertyChanged(nameof(SearchSourceIp));

                    if (string.IsNullOrWhiteSpace(_searchSourceIp))
                    {
                        ResetSearch();
                    }
                }
            }
        }




        private ObservableCollection<AlertGroupViewModel> _alertGroupViewModels = new ObservableCollection<AlertGroupViewModel>();

        public ObservableCollection<AlertGroupViewModel> AlertGroupViewModels
        {
            get => _alertGroupViewModels;
            set
            {
                _alertGroupViewModels = value;
                OnPropertyChanged(nameof(AlertGroupViewModels));
            }
        }

        public ObservableCollection<AlertGroupViewModel> AlertGroups { get; set; } = new ObservableCollection<AlertGroupViewModel>();

        private string _localIp = ConfigurationManager.GetLocalIpAddress();
        private bool _isSearching = false;
        private readonly AlertRepository _alertRepository;
        public MainWindowViewModel(User user)
        {
            CurrentUser = new User { Role = "Guest", Username = "Niezalogowany" };

            SearchAlertsByIpCommand = new RelayCommand<object>(_ => SearchAlertsByIp());


            if (!IsConfigurationValid())
            {
                MessageBox.Show("Brak wymaganej konfiguracji. Przejdź do zakładki konfiguracji, aby uzupełnić dane.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);

                SelectedTabIndex = 1;
                return;
            }

            string apiUrl = ConfigurationManager.GetSetting("ApiAddress");
            _alertRepository = new AlertRepository(apiUrl);

            InitializeSnortAndMonitoring();

            UpdateAlertStatusCommand = new RelayCommand<int>(async (alertId) => await UpdateAlertStatus(alertId, "resolved"));
            SelectedTabIndex = 0;

            LoadAlerts();

            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(5)
            };
            _timer.Tick += CheckForNewAlerts;
            _timer.Start();
        }
        public void InitializeSnortAndMonitoring()
        {
            if (_isSnortInitialized)
            {
                MessageBox.Show("Snort jest już uruchomiony i gotowy do działania.", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                string snortLogPath = ConfigurationManager.GetSetting("SnortInstallationPath") + @"\log\alert.ids";
                string apiUrl = ConfigurationManager.GetSetting("ApiAddress");

                _snortManagerService = new SnortManagerService();
                _snortAlertMonitor = new SnortAlertMonitor(snortLogPath, apiUrl, Application.Current.Dispatcher);
                _snortAlertMonitor.AlertReceived += OnAlertReceived;

                StartSnortAndMonitorLogs();
                _isSnortInitialized = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Błąd podczas uruchamiania Snort: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        public async void LoadAlerts()
        {
            if (_isSearching)
            {
                return;
            }

            try
            {
                List<Alert> alerts = CurrentUser.Role switch
                {
                    "Guest" => await _alertRepository.GetAlertsAsync(ip: _localIp),
                    "Administrator" => await _alertRepository.GetAlertsAsync(),
                    _ => throw new InvalidOperationException("Nieznana rola użytkownika.")
                };

                GroupAndDisplayAlerts(alerts);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas ładowania alertów: {ex.Message}");
            }
        }


        private void GroupAndDisplayAlerts(List<Alert> alerts)
        {
            var groupedAlerts = alerts
                .GroupBy(a => a.DestinationIp)
                .Select(group => new
                {
                    DestinationIp = group.Key,
                    Alerts = group.ToList()
                });

            foreach (var group in groupedAlerts)
            {
                var existingGroup = AlertGroupViewModels.FirstOrDefault(g => g.DestinationIp == group.DestinationIp);

                if (existingGroup != null)
                {
                    foreach (var alert in group.Alerts)
                    {
                        if (!existingGroup.Alerts.Any(a => a.Id == alert.Id))
                        {
                            existingGroup.Alerts.Add(alert);
                        }
                    }
                }
                else
                {
                    AlertGroupViewModels.Add(new AlertGroupViewModel
                    {
                        DestinationIp = group.DestinationIp,
                        Alerts = new ObservableCollection<Alert>(group.Alerts),
                        IsExpanded = false
                    });
                }
            }

            for (int i = AlertGroupViewModels.Count - 1; i >= 0; i--)
            {
                var group = AlertGroupViewModels[i];
                if (!groupedAlerts.Any(g => g.DestinationIp == group.DestinationIp))
                {
                    AlertGroupViewModels.RemoveAt(i);
                }
            }
        }



        private void SortGroupsByLatestAlert()
        {
            var sortedGroups = AlertGroupViewModels
                .OrderByDescending(g => g.Alerts.Max(a => a.Timestamp))
                .ToList();

            AlertGroupViewModels.Clear();
            foreach (var group in sortedGroups)
            {
                AlertGroupViewModels.Add(group);
            }
        }


        private void UpdateCurrentView()
        {
            if (SelectedTabIndex == 0)
            {
                CurrentView = new AlertsView
                {
                    DataContext = this
                };
            }
            else if (SelectedTabIndex == 1)
            {
                CurrentView = new ConfigurationView
                {
                    DataContext = new ConfigurationViewModel()
                };
            }
        }

        public async Task UpdateAlertStatus(int alertId, string newStatus)
        {
            try
            {
                await _alertRepository.UpdateAlertStatusAsync(alertId, newStatus);
                Console.WriteLine($"Zaktualizowano status alertu o ID {alertId} na {newStatus}");

                LoadAlerts();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas aktualizacji alertu: {ex.Message}");
                MessageBox.Show($"Błąd podczas aktualizacji alertu: {ex.Message}", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task<User> LoginUserAsync(string username, string password)
        {
            try
            {
                using var client = new HttpClient();
                client.BaseAddress = new Uri(ConfigurationManager.GetSetting("ApiAddress"));
                var credentials = new { Username = username, Password = password };

                var response = await client.PostAsJsonAsync("/api/auth/login", credentials);

                if (response.IsSuccessStatusCode)
                {
                    var user = await response.Content.ReadFromJsonAsync<User>();
                    if (user != null)
                    {
                        CurrentUser = user;
                        IsAdminLoggedIn = user.Role == "Administrator";

                        AlertGroupViewModels.Clear();

                        LoadAlerts();

                        return user;
                    }
                }
                else
                {
                    Console.WriteLine($"Błąd logowania: {response.StatusCode} - {response.ReasonPhrase}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas logowania: {ex.Message}");
            }

            return null;
        }



        private void StartSnortAndMonitorLogs()
        {
            try
            {
                _snortProcess = _snortManagerService.StartSnort();

                if (_snortProcess == null)
                {
                    MessageBox.Show("Nie udało się uruchomić Snorta. Sprawdź konfigurację.", "Błąd", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Task.Run(() => _snortAlertMonitor.StartMonitoringAsync());

                Console.WriteLine("Snort i monitorowanie logów zostały uruchomione.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas uruchamiania Snorta: {ex.Message}");
            }
        }

        public void StopSnort()
        {
            if (_snortProcess != null && !_snortProcess.HasExited)
            {
                try
                {
                    _snortProcess.Kill();
                    _snortProcess.WaitForExit();
                    Console.WriteLine("Snort został zatrzymany.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Błąd podczas zatrzymywania Snorta: {ex.Message}");
                }
            }
        }

        private void OnAlertReceived(Alert alert)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                if (CurrentUser.Role == "Guest" && alert.DestinationIp != _localIp)
                {
                    return;
                }

                var existingGroup = AlertGroupViewModels.FirstOrDefault(g => g.DestinationIp == alert.DestinationIp);
                if (existingGroup != null)
                {
                    if (!existingGroup.Alerts.Any(a => a.Id == alert.Id))
                    {
                        existingGroup.Alerts.Add(alert);
                    }
                }
                else
                {
                    AlertGroupViewModels.Add(new AlertGroupViewModel
                    {
                        DestinationIp = alert.DestinationIp,
                        Alerts = new ObservableCollection<Alert> { alert },
                        IsExpanded = false
                    });
                }
            });
        }

        private async void CheckForNewAlerts(object sender, EventArgs e)
        {
            if (_isSearching)
            {
                return;
            }

            try
            {
                var allAlerts = CurrentUser.Role switch
                {
                    "Guest" => await _alertRepository.GetAlertsAsync(ip: _localIp),
                    "Administrator" => await _alertRepository.GetAlertsAsync(),
                    _ => throw new InvalidOperationException("Nieznana rola użytkownika.")
                };

                GroupAndDisplayAlerts(allAlerts);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas sprawdzania nowych alertów: {ex.Message}");
            }
        }


        private async void SearchAlertsByIp()
        {
            if (string.IsNullOrWhiteSpace(SearchSourceIp))
            {
                MessageBox.Show("Wprowadź poprawny adres IP", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                _isSearching = true; // Zablokuj odświeżanie
                var alerts = await _alertRepository.GetAlertsAsync();

                var filteredAlerts = alerts.Where(a => a.SourceIp == SearchSourceIp || a.DestinationIp == SearchSourceIp).ToList();

                GroupAndDisplayAlerts(filteredAlerts);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Błąd podczas wyszukiwania alertów: {ex.Message}");
            }
        }




        private void ResetSearch()
        {
            if (_isSearching)
            {
                _isSearching = false;
                LoadAlerts();
            }
        }

        private bool IsConfigurationValid()
        {
            string snortPath = ConfigurationManager.GetSetting("SnortInstallationPath");
            string apiUrl = ConfigurationManager.GetSetting("ApiAddress");
            string snortInstallationPath = ConfigurationManager.GetSetting("SnortInstallationPath");

            return !string.IsNullOrEmpty(snortPath) && !string.IsNullOrEmpty(apiUrl) && !string.IsNullOrEmpty(snortInstallationPath);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}